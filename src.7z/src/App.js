import React from 'react';

function App() {
    const Users = [
        {
            id: 1,
            name: 'Fluffy',
            hobby: 'Sleep and eat',
            sleeping: 'Under the sofa',
        },
        {
            id: 2,
            name: 'Duffy',
            hobby: 'Yell at night and piss in slippers',
            sleeping: 'On the door',
        },
        {
            id: 3,
            name: 'Heisenberg',
            hobby: "Spoil the neighbor's cats",
            sleeping: 'Outdoors',
        },
    ];

    return (
        <div>
            <h4>List of cats</h4>
            <ul>
                {Users.map((data) => (
                    <li key={data.id}>
                        <div>{data.name}</div>
                        <div>{data.hobby}</div>
                        <div>{data.sleeping}</div>
                    </li>
                ))}
            </ul>
        </div>
    );
}
export default App;
